﻿using System;
using System.Collections.Generic;

#nullable disable

namespace StockBackend.Models
{
    public partial class Stock
    {
        public long Id { get; set; }
        public long CompanyCode { get; set; }
        public decimal? Stockprice { get; set; }
        public DateTime? CreatedTime { get; set; }

        public virtual Company CompanyCodeNavigation { get; set; }
    }
}
