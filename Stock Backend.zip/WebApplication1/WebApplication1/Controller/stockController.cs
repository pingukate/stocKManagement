﻿using StockBackend.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace StockBackend.Controller
{
    [Route("api/v1.0/market/[controller]")]
    [ApiController]
    public class stockController : ControllerBase
    {
        EstockContext _db = new EstockContext();
        [HttpGet("[action]")]
        public IActionResult getallstocks()
        {
            return Ok(_db.Stocks);
        }

        // GET api/<stockController>/5
        [HttpGet("[action]/{companycode}/{startdate}/{enddate}")]
        public IActionResult get(long companycode, DateTime startdate, DateTime enddate)
        {
            var data1 = _db.Stocks.Where(x=> x.CreatedTime >= startdate && x.CreatedTime <= enddate).ToList();
            return Ok(data1);
        }

        // POST api/<stockController>
        [HttpPost("[action]/{companycode}")]
        [ProducesResponseType(typeof(stockResponse), 200)]
        public IActionResult add([FromBody] Stock stock, long companycode)
        {
            stockResponse response = new stockResponse();
            var category = _db.Companies.FirstOrDefault(c => c.CompanyCode == companycode);
            if (category != null)
            {
                _db.Stocks.Add(stock);
                // _db.SaveChanges();
                int count = _db.SaveChanges();
                // return Ok("Record Created Successfully");
                response.status = count;
                response.message = "Stock inserted successfully.";
                return Ok(response);
                // return Ok("Stock inserted Successfully");
            }
            else
            {
                response.status = 0;
                response.message = "Company code " + companycode + " is not present in Company Table.";
                return Ok(response);
                // return NotFound("Company code "+ companycode +" is not present in Company Table.");
            }             
        }

    }
}
