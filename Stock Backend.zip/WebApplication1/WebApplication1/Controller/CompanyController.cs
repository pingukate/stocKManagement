﻿using StockBackend.Models;
using Microsoft.AspNetCore.Mvc;
using System.Linq;


// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace StockBackend.Controller
{
    [Route("api/v1.0/market/[controller]")]
    [ApiController]
    public class CompanyController : ControllerBase
    {
        EstockContext _db = new EstockContext();

        // GET: api/<CompanyController>
        [HttpGet("[action]")]
        public IActionResult getall()
        {
            return Ok(_db.Companies);
        }

        // GET api/<CompanyController>/5
        [HttpGet("[action]/{companycode}")]
        public IActionResult info(int companycode)
        {
            var category = _db.Companies.FirstOrDefault(c => c.CompanyCode == companycode);
            if (category == null)
            {
                return NotFound("Enter Valid Company Code");
            }
            return Ok(category);
        }


        // POST api/<CompanyController>
        [HttpPost("[action]")]
        [ProducesResponseType(typeof(Response), 200) ]
        public IActionResult register([FromBody] Company category)
        {
            Response response = new Response();
            var companyadd = _db.Companies.FirstOrDefault(c => c.CompanyCode == category.CompanyCode);
            if (companyadd!=null)
            {
                // return Ok("Do not enter duplicate record");
                response.status = 0;
                response.message = "Do not enter duplicate record. Please enter unique company code";
                return Ok(response);
            } else
            {
                _db.Companies.Add(category);
                int count = _db.SaveChanges();
                // return Ok("Record Created Successfully");
                response.status = count;
                response.message = "Record created successfully";
                return Ok( response );
            }
        }


        // DELETE api/<CompanyController>/5
        [HttpDelete("[action]/{companycode}")]
        public IActionResult delete(long companycode)
        {
            // var stocks = _db.Stocks;
            int stockCheck = _db.Stocks.Count();
            for (var i = 0; i < stockCheck; i++)
            {
                var Stocksdel = _db.Stocks.FirstOrDefault(c => c.CompanyCode == companycode);
                if (Stocksdel != null)
                {
                    _db.Stocks.Remove(Stocksdel);
                    _db.SaveChanges();
                }
            }
            var Stocksdelete = _db.Stocks.FirstOrDefault(c => c.CompanyCode == companycode);
            var companydelete = _db.Companies.FirstOrDefault(c => c.CompanyCode == companycode);
            //var Stocksdelete = _db.Stocks.Find(companycode);
            //var companydelete = _db.Companies.Find(companycode);
            if (Stocksdelete == null && companydelete == null)
            {
                return NotFound("Company code " + companycode + " is not present in Company Table.");
            }
            if (companydelete != null)
            {
                _db.Companies.Remove(companydelete);
                _db.SaveChanges();
            }       
            return Ok("Record Deleted Successfully");
        }
    }
}
