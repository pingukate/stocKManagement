export const environment = {
  production: true,
  servername: 'http://load-balancer-final-1535937963.us-east-2.elb.amazonaws.com'
};
