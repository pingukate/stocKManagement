import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs';
import { ServiceGlobal } from '../globals/service.globals';

@Injectable({
  providedIn: 'root'
})
export class StocksService {

  serviceGlobal = this.environmentGlobal.getServiceList();

  constructor(
    private environmentGlobal: ServiceGlobal,
    private http: HttpClient
  ) { }

  private stockAddSubject = new BehaviorSubject<any>({});
  stockObservable = this.stockAddSubject.asObservable();

  facadeAddStock(request: any): void {
    this.stockAddSubject.next({});
    this.addStockService(request).subscribe((data) => {
      this.stockAddSubject.next(data);
    })
  }

  addStockService(requestObject: any) {
    const serviceUrl = this.serviceGlobal.ADD_NEW_STOCK_PRICE + requestObject.companyCode;
    return this.http.post<any>(serviceUrl, requestObject);
  }

  getAllStocks() {
    const serviceUrl = this.serviceGlobal.GET_ALL_STOCKS;
    return this.http.get<any>(serviceUrl);
  }

  getSpecificStocks(requestObject: any) {
    const serviceUrl = this.serviceGlobal.FETCH_STOCK_PRICE_LIST
    const dataUrl = requestObject.companyCode + '/' + requestObject.startDate + '/' + requestObject.endDate;
    return this.http.get<any>(serviceUrl + dataUrl);
  }
}
