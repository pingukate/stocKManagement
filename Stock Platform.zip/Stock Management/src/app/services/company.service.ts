import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { ServiceGlobal } from '../globals/service.globals';

@Injectable({
  providedIn: 'root'
})
export class CompanyService {

  serviceGlobal = this.environmentGlobal.getServiceList();

  constructor(
    private environmentGlobal: ServiceGlobal,
    private http: HttpClient
    ) { }

    private companyRegisterSubject = new BehaviorSubject<any>({});
    companyRegisterObservable = this.companyRegisterSubject.asObservable();

    facadeCompanyRegister(request: any): void {
      this.companyRegisterSubject.next({});
      this.addCompanyService(request).subscribe((data)=>{
        this.companyRegisterSubject.next(data);
      })
    }

    addCompanyService(requestObject: any) {
      const serviceUrl = this.serviceGlobal.ADD_COMPANY;
      return this.http.post<any>(serviceUrl, requestObject);
    }

    getAllCompany() {
      const serviceUrl = this.serviceGlobal.GET_ALL_COMPANY;
      return this.http.get<any>(serviceUrl);
    }
}
