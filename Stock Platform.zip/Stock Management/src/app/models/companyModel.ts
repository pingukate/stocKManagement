

interface company {
    companyCeo: string;
    companyCode: number;
    companyName: string;
    companyTurnover: number;
    companyWebsite: string;
    id?: number;
    stockExchange: string
    stocks: stock[]
}

interface stock {
    stockPrice: number,
    date: Date,
    time: Date
}

export { company, stock }