import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { DialogModule } from 'primeng/dialog';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit, OnDestroy {

  loginForm: FormGroup;
  openModal: boolean;
  dialogBox = {
    title: '',
    visibility: false,
    message: ''
  }

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
  ) { }

  ngOnInit(): void {
    this.loginForm = this.formBuilder.group({
      username: ['', [Validators.required]],
      password: ['', Validators.required]
    });
  }

  onSignIn() {
    const requestObject = {
      username: this.loginForm.controls.username.value,
      password: this.loginForm.controls.password.value
    };

    if(requestObject.username === 'username' && requestObject.password === 'password')
          {
            this.router.navigateByUrl('/dashboard');
          }
          else{
            this.showPopUp('Invalid Credentials, Please try again.', 'Error');
          }
  }

  showPopUp(message, value): void {
    this.dialogBox = {
      visibility: true,
      message: message,
      title: value
    }; 
    setTimeout(() => {
      this.dialogBox = {
        visibility: false,
        message: '',
        title: ''
      }; 
    }, 5000);
  }

  resetForm(): void {
    this.loginForm.reset();
  }

  ngOnDestroy(): void {
  }

}
