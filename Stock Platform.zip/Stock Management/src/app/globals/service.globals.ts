import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';

@Injectable({
    providedIn: 'root'
})
export class ServiceGlobal {

    constructor() { }

    getServiceList(): { [key: string]: string } {
        return {
            ADD_COMPANY: environment.servername + '/api/v1.0/market/company/register',
            GET_SPECIFIC_COMPANY: environment.servername + '/api/v1.0/market/company/info/<companycode>',
            GET_ALL_COMPANY: environment.servername + '/api/v1.0/market/company/getall',
            DELETE_COMPANY: environment.servername + '/api/v1.0/market/company/delete/<companycode>',
            ADD_NEW_STOCK_PRICE: environment.servername + '/api/v1.0/market/stock/add/',
            FETCH_STOCK_PRICE_LIST: environment.servername + '/api/v1.0/market/stock/get/',
            GET_ALL_STOCKS: environment.servername + '/api/v1.0/market/stock/getallstocks'
        };
    }
}
