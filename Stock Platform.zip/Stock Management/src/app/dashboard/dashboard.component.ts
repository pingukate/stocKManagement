import { Component, OnDestroy, OnInit, DoCheck } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { company, stock } from '../models/companyModel';
import { CompanyService } from '../services/company.service';
import { StocksService } from '../services/stocks.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit, OnDestroy, DoCheck {

  addCompanyFlag = false;
  addStockFlag = false;
  dashboardFlag = false;
  listAllFlag = false;
  addForm: FormGroup;
  stockForm: FormGroup;
  turnOverFlag = false;
  changeFlag;
  searchValue;
  date;
  companies: company[];
  company: company[];
  stocks: stock[];
  companyStock: stock[] = [];
  startDate: any;
  endDate: any;
  private unSubscribe = new Subject();
  minDateToHold = new Subject<string>();

  summaryCalculation: any[] = [];

  minimumStock = 0;
  maximumStock = 0;
  average = 1;
  dialogBox = {
    title: '',
    visibility: false,
    message: ''
  };
  stockAdd = {
    title: '',
    visibility: false,
    message: ''
  };
  companyCode: any;
  stockPrices: any = [];
  minDate;
  searchDisable;
  dateDisable: boolean;
  companyStockBoolean: boolean = false;

  nullStock = [ {}
//     {
//     stockPrice: '',
//     noResult: 'no results found',
//     date: ''
//   }
];

  startDateChange(e) {
    this.minDateToHold.next(e.toString());
  }

  constructor(
    private router: Router,
    public formBuilder: FormBuilder,
    private companyService: CompanyService,
    private stockService: StocksService
  ) {
    this.minDateToHold.subscribe(r => {
      this.minDate = new Date(r);
    })
  }

  ngOnInit(): void {
    this.dashboardFlag = true;
    this.searchDisable = true;
    this.date = new Date();
    this.addForm = this.formBuilder.group({
      cCode: ['', [Validators.required, Validators.pattern('^[0-9ñÑáéíóúÁÉÍÓÚ ]+$')]],
      cName: new FormControl(null, [Validators.required]),
      cCEO: new FormControl(null, [Validators.required]),
      cTurnover: ['', [Validators.required, Validators.minLength(7), Validators.pattern('^[0-9ñÑáéíóúÁÉÍÓÚ ]+$')]],
      cWebsite: new FormControl(null, [Validators.required]),
      cStockExchange: new FormControl(null, [Validators.required]),
    });
    this.stockForm = this.formBuilder.group({
      cStockPrice: new FormControl('', [Validators.required])
    })
    this.companyList();
  }

  ngDoCheck () {
    if (this.searchValue == '' || this.searchValue == undefined) {
      this.searchDisable = true;
    } else {
      this.searchDisable = false;
    }
    
    if (this.startDate == undefined || this.endDate == undefined || this.startDate == '' || this.endDate == '') {
      this.dateDisable = true;
    } else {
      this.dateDisable = false;
    }
  }

  saveStock() {
    const reqObject = {
      companyCode: this.companyCode,
      stockPrice: this.stockForm.get('cStockPrice').value,
      createdTime: new Date().toISOString()
    };
    this.stockService.facadeAddStock(reqObject);
    this.stockService.stockObservable.pipe(takeUntil(this.unSubscribe))
      .subscribe(serviceData => {
        if (Object.keys(serviceData).length > 0) {
          this.showStockSuccessPopup(serviceData.message);
        }

      })
  }

  showStockSuccessPopup(data) {
    this.stockAdd = {
      visibility: true,
      message: data,
      title: 'Success'
    };
    this.stockForm.reset();
  }

  onDialogStockClose() {
    this.stockAdd.visibility = false;
    this.companyStock = [];
    this.summaryCalculation = [];
    this.stockPrices = [];

    this.stockService.getAllStocks().subscribe(
      data => {
        if (Object.keys(data).length > 0) {
          // this.companies = data;
          this.stocks = data.forEach(item => {
            if (item.companyCode == this.companyCode) {
              const date = new Date(item.createdTime)
              this.companyStock.push(
                {
                  stockPrice: item.stockprice,
                  date: date,
                  time: date
                }
              )
            }
          });
          if (this.companyStock.length > 0) {
            this.companyStockBoolean = true;
          } else {
            this.companyStockBoolean = false;
          }
          this.companyStock.forEach(item => {
            this.stockPrices.push(item.stockPrice);
          })
          const temp = {
            minimumStock: this.stockPrices.length > 0 ? Math.min(...this.stockPrices) : 0,
            maximumStock: this.stockPrices.length > 0 ? Math.max(...this.stockPrices) : 0,
            average: this.stockPrices.length > 0 ? this.calculateAverage(this.stockPrices) : 0
          };
          this.summaryCalculation.push(temp);
        }
      }
    )
  }

  companyList() {
    this.companyService.getAllCompany().subscribe(
      data => {
        if (Object.keys(data).length > 0) {
          this.companies = data;
        }
      }
    )
    // this.companies = [
    //   { companyCode: '1', companyName: 'Tata' },
    //   { companyCode: '1', companyName: 'Tata' },
    //   { companyCode: '1', companyName: 'Tata' },
    //   { companyCode: '1', companyName: 'Tata' },
    //   { companyCode: '1', companyName: 'Tata' },
    //   { companyCode: '1', companyName: 'Tata' },
    //   { companyCode: '1', companyName: 'Tata' },
    //   { companyCode: '1', companyName: 'Tata' },
    //   { companyCode: '1', companyName: 'Tata' }
    // ];
  }

  addCompany() {
    this.addCompanyFlag = true;
    this.dashboardFlag = false;
    this.listAllFlag = false;
    this.addStockFlag = false;
  }

  // onSearch() {
  //   this.addStockFlag = true;
  //   this.dashboardFlag = false;
  //   this.addCompanyFlag = false;
  //   this.listAllFlag = false;
  // }

  searchDateList() {
    this.companyStock = [];
    this.summaryCalculation = [];
    this.stockPrices = [];
    const request = {
      startDate: this.startDate.toISOString(),
      endDate: this.endDate.toISOString(),
      companyCode: this.companyCode
    }
    this.stockService.getSpecificStocks(request).subscribe(data =>{
      if (Object.keys(data).length > 0) {
        this.stocks = data.forEach(item => {
          if (item.companyCode == this.companyCode) {
            const date = new Date(item.createdTime)
            this.companyStock.push(
              {
                stockPrice: item.stockprice,
                date: date,
                time: date
              }
            );
          }
        });
        if (this.companyStock.length > 0) {
          this.companyStockBoolean = true;
        } else {
          this.companyStockBoolean = false;
        }
        this.companyStock.forEach(item => {
          this.stockPrices.push(item.stockPrice);
        })
        const temp = {
          minimumStock: this.stockPrices.length > 0 ? Math.min(...this.stockPrices) : 0,
          maximumStock: this.stockPrices.length > 0 ? Math.max(...this.stockPrices) : 0,
          average: this.stockPrices.length > 0 ? this.calculateAverage(this.stockPrices) : 0
        };
        this.summaryCalculation.push(temp);
      } else {
        this.companyStockBoolean = false;
        this.dateDisable = true;
      }
    });
    this.startDate = '';
    this.endDate = '';
  }

  getAllCompanies() {
    this.listAllFlag = true;
    this.dashboardFlag = false;
    this.addCompanyFlag = false;
    this.addStockFlag = false;
    this.companyService.getAllCompany().subscribe(
      data => {
        if (Object.keys(data).length > 0) {
          this.company = data;
        }
      }
    )
    // this.company = [
    //   { companyCode: '1', companyName: 'Tata' },
    //   { companyCode: '1', companyName: 'Tata' },
    //   { companyCode: '1', companyName: 'Tata' },
    //   { companyCode: '1', companyName: 'Tata' },
    //   { companyCode: '1', companyName: 'Tata' },
    //   { companyCode: '1', companyName: 'Tata' },
    //   { companyCode: '1', companyName: 'Tata' },
    //   { companyCode: '1', companyName: 'Tata' },
    //   { companyCode: '1', companyName: 'Tata' }
    // ];
  }

  dashboard() {
    this.dashboardFlag = true;
    this.addCompanyFlag = false;
    this.listAllFlag = false;
    this.addStockFlag = false;
  }

  dropdownChange(e) {
    this.addStockFlag = true;
    this.dashboardFlag = false;
    this.addCompanyFlag = false;
    this.listAllFlag = false;
    this.companyCode = e.value ? e.value.companyCode : parseInt(this.searchValue);
    this.companyStock = [];
    this.summaryCalculation = [];
    this.stockPrices = [];
    this.stockService.getAllStocks().subscribe(
      data => {
        if (Object.keys(data).length > 0) {
          // this.companies = data;
          this.stocks = data.forEach(item => {
            if (item.companyCode == this.companyCode) {
              const date = new Date(item.createdTime)
              this.companyStock.push(
                {
                  stockPrice: item.stockprice,
                  date: date,
                  time: date
                }
              )
            }
          });
          if (this.companyStock.length > 0) {
            this.companyStockBoolean = true;
          } else {
            this.companyStockBoolean = false;
          }
          this.companyStock.forEach(item => {
            this.stockPrices.push(item.stockPrice);
          })
          const temp = {
            minimumStock: this.stockPrices.length > 0 ? Math.min(...this.stockPrices) : 0,
            maximumStock: this.stockPrices.length > 0 ? Math.max(...this.stockPrices) : 0,
            average: this.stockPrices.length > 0 ? this.calculateAverage(this.stockPrices) : 0
          };
          this.summaryCalculation.push(temp);

          // (item =>{
          //   if(item.companyCode == this.companyCode) {
          //     const date = new Date(item.createdTime)
          //     const tempStock = {
          //       stockPrice : item.stockPrice,
          //       date: date.getDate(),
          //       time: date.getTime()
          //     };
          //     return tempStock;
          //   }
          // });
        }
      }
    )
    this.searchValue = '';

  }

  calculateAverage(array) {
    let total = 0;
    let count = 0;
    array.forEach(function (element, index) {
      total += element;
      count++
    });
    const avg = total / count;
    return avg.toFixed(2);
  }

  submit() {
    const reqObj = {
      companyCode: this.addForm.get('cCode').value,
      companyName: this.addForm.get('cName').value,
      companyCeo: this.addForm.get('cCEO').value,
      companyTurnover: this.addForm.get('cTurnover').value,
      companyWebsite: this.addForm.get('cWebsite').value,
      stockExchange: this.addForm.get('cStockExchange').value,
    };
    this.companyService.facadeCompanyRegister(reqObj);
    this.companyService.companyRegisterObservable.pipe(takeUntil(this.unSubscribe))
      .subscribe(serviceData => {
        if (Object.keys(serviceData).length > 0) {
          this.showSuccessPopup(serviceData.message);
        }

      })
  }

  showSuccessPopup(data) {
    this.dialogBox = {
      visibility: true,
      message: data,
      title: 'Success'
    };
    this.addForm.reset();
  }

  onDialogClose() {
    this.dialogBox.visibility = false;
    this.companyService.getAllCompany().subscribe(
      data => {
        if (Object.keys(data).length > 0) {
          this.company = data;
          this.companies = data;
        }
      }
    )
  }

  turnoverChange(e) {
    if (this.addForm.value.cTurnover >= 1000000) {
      this.turnOverFlag = false;
    } else { this.turnOverFlag = true; }
  }

  logout() {
    this.router.navigateByUrl('/login');
  }

  ngOnDestroy() {
    this.unSubscribe.next();
    this.unSubscribe.complete();
  }

}

