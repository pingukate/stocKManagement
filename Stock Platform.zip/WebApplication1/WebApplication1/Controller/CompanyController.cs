﻿using StockBackend.Models;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DataModel;
using System.Collections.Generic;
using System;
using System.Threading.Tasks;
using Amazon.DynamoDBv2.DocumentModel;


// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace StockBackend.Controller
{
    [Route("api/v1.0/market/[controller]")]
    [ApiController]
    public class CompanyController : ControllerBase
    {
        private readonly IAmazonDynamoDB _amazonDynamoDB;
        private readonly IDynamoDBContext _context;
        public CompanyController(IAmazonDynamoDB amazonDynamoDB) {
            _amazonDynamoDB = amazonDynamoDB;
            DynamoDBContext _context = new DynamoDBContext(_amazonDynamoDB);
        }

        static int generateId() {
            Random rand = new Random((int)DateTime.Now.Ticks);
            int randomNumber;
            randomNumber = rand.Next(1, 9999999);
            return randomNumber;
        }

        // GET: api/<CompanyController>
        [HttpGet("[action]")]
        public async Task<IActionResult> getall()
        {
            DynamoDBContext context = new DynamoDBContext(_amazonDynamoDB);
            var conditions = new List<ScanCondition>();
            return Ok(await context.ScanAsync<Company>(conditions).GetRemainingAsync());
        }

        // GET api/<CompanyController>/5
        [HttpGet("[action]/{companycode}")]
        public async Task<IActionResult> info(int companycode)
        {
            DynamoDBContext context = new DynamoDBContext(_amazonDynamoDB);
            var search = context.ScanAsync<Company>
                (
                new[]
                {
                    new ScanCondition
                    (
                        nameof(Company.CompanyCode),
                        ScanOperator.Equal,
                        companycode
                        )
                }
                );
            var category = await search.GetRemainingAsync();
            if (category.Count == 0)
            {
                return NotFound("Enter Valid Company Code");
            }
            return Ok(category);
        }


        // POST api/<CompanyController>
        [HttpPost("[action]")]
        [ProducesResponseType(typeof(Response), 200) ]
        public async Task<IActionResult> register([FromBody] Company category)
        {
            DynamoDBContext context = new DynamoDBContext(_amazonDynamoDB);
            Response response = new Response();
            var search = context.ScanAsync<Company>
                (
                new[]
                {
                    new ScanCondition
                    (
                        nameof(Company.CompanyCode),
                        ScanOperator.Equal,
                        category.CompanyCode
                        )
                }
                );
            var companyadd = await search.GetRemainingAsync();
            if (companyadd.Count != 0)
            {
                response.status = 0;
                response.message = "Do not enter duplicate record. Please enter unique company code";
                return Ok (response);
            } else
            {
                Company comp = new Company { 
                    Id = generateId(),
                    CompanyCeo = category.CompanyCeo,
                    CompanyCode = category.CompanyCode,
                    CompanyName = category.CompanyName,
                    CompanyTurnover = category.CompanyTurnover,
                    CompanyWebsite = category.CompanyWebsite,
                    StockExchange = category.StockExchange
                };
                await context.SaveAsync(comp);
                response.status = 1;
                response.message = "Record created successfully";
                return Ok (response);
            }
        }


        // DELETE api/<CompanyController>/5
        [HttpDelete("[action]/{companycode}")]
        public async Task<IActionResult> delete(int companycode)
        {
            DynamoDBContext context = new DynamoDBContext(_amazonDynamoDB);
            var stockSearch = context.ScanAsync<Stock>
                (
                new[]
                {
                    new ScanCondition
                    (
                        nameof(Stock.CompanyCode),
                        ScanOperator.Equal,
                        companycode
                        )
                }
                );
            var stockCheck = await stockSearch.GetRemainingAsync();
            for (var i = 0; i < stockCheck.Count; i++)
            {
                await context.DeleteAsync<Stock>(stockCheck[i]);
            }
            var stockEmpty = context.ScanAsync<Stock>
               (
               new[]
               {
                    new ScanCondition
                    (
                        nameof(Stock.CompanyCode),
                        ScanOperator.Equal,
                        companycode
                        )
               }
               );
            var Stocksdelete = await stockEmpty.GetRemainingAsync();
            var companyEmpty = context.ScanAsync<Company>
               (
               new[]
               {
                    new ScanCondition
                    (
                        nameof(Company.CompanyCode),
                        ScanOperator.Equal,
                        companycode
                        )
               }
               );
            var companydelete = await companyEmpty.GetRemainingAsync();
            if (Stocksdelete.Count == 0 && companydelete.Count == 0)
            {
                return NotFound("Company code " + companycode + " is not present in Company Table.");
            }
            if (companydelete.Count != 0)
            {
                await context.DeleteAsync(companydelete[0]);
            }       
            return Ok("Record Deleted Successfully");
        }
    }
}
