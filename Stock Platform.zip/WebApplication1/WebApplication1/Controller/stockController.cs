﻿using StockBackend.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;
using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DataModel;
using System.Collections.Generic;
using System.Threading.Tasks;
using Amazon.DynamoDBv2.DocumentModel;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace StockBackend.Controller
{
    [Route("api/v1.0/market/[controller]")]
    [ApiController]
    public class stockController : ControllerBase
    {
        private readonly IAmazonDynamoDB _amazonDynamoDB;
        private readonly IDynamoDBContext _context;
        public stockController(IAmazonDynamoDB amazonDynamoDB)
        {
            _amazonDynamoDB = amazonDynamoDB;
            DynamoDBContext _context = new DynamoDBContext(_amazonDynamoDB);
        }

        static int generateId()
        {
            Random rand = new Random((int)DateTime.Now.Ticks);
            int randomNumber;
            randomNumber = rand.Next(1, 9999999);
            return randomNumber;
        }

        [HttpGet("[action]")]
        public async Task<IActionResult> getallstocks()
        {
            DynamoDBContext context = new DynamoDBContext(_amazonDynamoDB);
            var conditions = new List<ScanCondition>();
            return Ok(await context.ScanAsync<Stock>(conditions).GetRemainingAsync());
        }

        // GET api/<stockController>/5/startdate/enddate
        [HttpGet("[action]/{companycode}/{startdate}/{enddate}")]
        public async Task<IActionResult> get(long companycode, DateTime startdate, DateTime enddate)
        {
            DynamoDBContext context = new DynamoDBContext(_amazonDynamoDB);
            var search = context.ScanAsync<Stock>
                (
                new[]
                {
                    new ScanCondition
                    (
                        nameof(Stock.CreatedTime),
                        ScanOperator.Between,
                        startdate,
                        enddate
                        )
                }
                );
            var category = await search.GetRemainingAsync();
            return Ok(category);
        }

        // POST api/<stockController>
        [HttpPost("[action]/{companycode}")]
        [ProducesResponseType(typeof(stockResponse), 200)]
        public async Task<IActionResult> add([FromBody] Stock stock, int companycode)
        {
            stockResponse response = new stockResponse();
            DynamoDBContext context = new DynamoDBContext(_amazonDynamoDB);
            var search = context.ScanAsync<Company>
                (
                new[]
                {
                    new ScanCondition
                    (
                        nameof(Company.CompanyCode),
                        ScanOperator.Equal,
                        companycode
                        )
                }
                );
            var category = await search.GetRemainingAsync();
            if (category.Count != 0)
            {
                // _db.Stocks.Add(stock);
                // _db.SaveChanges();
                Stock comp = new Stock
                {
                    Id = generateId(),
                    Stockprice = stock.Stockprice,
                    CompanyCode = companycode,
                    CreatedTime = stock.CreatedTime
                };
                await context.SaveAsync(comp);
                response.status = 1;
                response.message = "Stock inserted successfully.";
                return Ok(response);
            }
            else
            {
                response.status = 0;
                response.message = "Company code " + companycode + " is not present in Company Table.";
                return Ok(response);
            }             
        }

    }
}
