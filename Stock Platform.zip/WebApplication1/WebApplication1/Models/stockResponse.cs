﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StockBackend.Models
{
    public class stockResponse
    {
        public int status { get; set; }
        public string message { get; set; }
    }
}
