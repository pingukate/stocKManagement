﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace StockBackend.Models
{
    public partial class EstockContext : DbContext
    {
        public EstockContext()
        {
        }

        public EstockContext(DbContextOptions<EstockContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Company> Companies { get; set; }
        public virtual DbSet<Stock> Stocks { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=CTSDOTNET172;Database=Estock;User ID=sa;Password=pass@word1");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<Company>(entity =>
            {
                entity.ToTable("Company");

                entity.HasIndex(e => e.CompanyCode, "UQ__Company__11A0134B816DD461")
                    .IsUnique();

                entity.Property(e => e.CompanyCeo)
                    .IsRequired()
                    .HasColumnName("CompanyCEO");

                entity.Property(e => e.CompanyName).IsRequired();

                entity.Property(e => e.CompanyTurnover).HasColumnType("decimal(30, 2)");

                entity.Property(e => e.CompanyWebsite).IsRequired();

                entity.Property(e => e.StockExchange).IsRequired();
            });

            modelBuilder.Entity<Stock>(entity =>
            {
                entity.ToTable("Stock");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedTime)
                    .HasColumnType("datetime")
                    .HasColumnName("createdTime");

                entity.Property(e => e.Stockprice).HasColumnType("decimal(30, 2)");

                // entity.HasOne(d => d.CompanyCodeNavigation)
                //     .WithMany(p => p.Stocks)
                //     .HasPrincipalKey(p => p.CompanyCode)
                //     .HasForeignKey(d => d.CompanyCode)
                //     .OnDelete(DeleteBehavior.ClientSetNull)
                //     .HasConstraintName("FK__Stock__CompanyCo__31EC6D26");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
