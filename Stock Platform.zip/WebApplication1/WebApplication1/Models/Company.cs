﻿using Amazon.DynamoDBv2.DataModel;
using System;
using System.Collections.Generic;

#nullable disable

namespace StockBackend.Models
{
    [DynamoDBTable("Company")]
    public partial class Company
    {
        // public Company()
        // {
        //     Stocks = new HashSet<Stock>();
        // }
        [DynamoDBHashKey]
        public int Id { get; set; }
        public int CompanyCode { get; set; }
        public string CompanyName { get; set; }
        public string CompanyCeo { get; set; }
        public decimal CompanyTurnover { get; set; }
        public string CompanyWebsite { get; set; }
        public string StockExchange { get; set; }

        // public virtual ICollection<Stock> Stocks { get; set; }
    }
}
