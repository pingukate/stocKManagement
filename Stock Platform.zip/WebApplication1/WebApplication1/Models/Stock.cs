﻿using Amazon.DynamoDBv2.DataModel;
using System;
using System.Collections.Generic;

#nullable disable

namespace StockBackend.Models
{
    [DynamoDBTable("Stock")]
    public partial class Stock
    {
        [DynamoDBHashKey]
        public int Id { get; set; }
        public int CompanyCode { get; set; }
        public decimal? Stockprice { get; set; }
        public DateTime? CreatedTime { get; set; }

        // public virtual Company CompanyCodeNavigation { get; set; }
    }
}
